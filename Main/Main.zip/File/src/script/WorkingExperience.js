const workingExperience = [
  {
    title: "Software Developer",
    company: "Unix Company",
    time: "2010-2012",
    text: "Diligent software engineer with 5+ years of experience in commercial application and software development. Eager to join Cyclone Inc. to build innovative and cutting-edge business solutions for the impressive suite of clients within its global reach.",
  },
  {
    title: "Back-end Developer",
    company: "Liza Yoolo ITC Company",
    time: "2012-2018",
    text: "Diligent software engineer with 5+ years of experience in commercial application and software development. Eager to join Cyclone Inc. to build innovative and cutting-edge business solutions for the impressive suite of clients within its global reach.",
  },
  {
    title: "Front-end Developer",
    company: "Ultra Luca Company",
    time: "2018-2021",
    text: "Diligent software engineer with 5+ years of experience in commercial application and software development. Eager to join Cyclone Inc. to build innovative and cutting-edge business solutions for the impressive suite of clients within its global reach.",
  },
  {
    title: "Software Developer",
    company: "Unix Company",
    time: "2021-2022",
    text: "Diligent software engineer with 5+ years of experience in commercial application and software development. Eager to join Cyclone Inc. to build innovative and cutting-edge business solutions for the impressive suite of clients within its global reach.",
  },
  {
    title: "Graphic Designer",
    company: "Unix Company",
    time: "2021-2022",
    text: "Diligent software engineer with 5+ years of experience in commercial application and software development. Eager to join Cyclone Inc. to build innovative and cutting-edge business solutions for the impressive suite of clients within its global reach.",
  },
];

export default workingExperience;
